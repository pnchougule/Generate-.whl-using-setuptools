from mypackage import  module1

module1.extract_pdf_by_coordinates()